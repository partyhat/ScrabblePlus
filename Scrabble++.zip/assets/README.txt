Place any non-code-related assets that your program uses in this directory.
Examples of such assets include image files, text files, etc. used by your 
program.

This directory already contains one asset you may use in your implementation. 
If your program uses any additional assets, please list them below:

    - words.txt
        A text file containing 64,000 lower-case words.